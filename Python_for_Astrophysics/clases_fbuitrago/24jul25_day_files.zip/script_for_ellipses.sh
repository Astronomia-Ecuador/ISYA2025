phys_scale=6.874 #[kpc/arcsec]
pa=90
ar=0.7

image_filename="./17058_goodss_H_hudf.fits"
mask_filename="./mask_H_for_profiles.fits"
band="VIS"
x_cen=185 
y_cen=184
max_radius=150
pix_per_aperture=3

pix_scaleVIS=0.06
skyVIS=0
extVIS=0.0045
zpVIS=25.946
sky_std_VIS=0.00312


case $band in
    "VIS")
    pix_scale=$pix_scaleVIS
	sky_bckg=$skyVIS
	extinction=$extVIS
	zp=$zpVIS
	sky_std=$sky_std_VIS
    ;;
esac

#I place NaNs instead of 0s for the mask
new_mask_filename="masked_with_nans.fits"
astarithmetic $mask_filename -h0 set-mask mask mask 0 eq nan where --output=$new_mask_filename

##I subtract the sky value I measured
#astarithmetic $image_filename -h0 $sky_F850LP - --output=sky_subtracted_image.fits

#I mask the science image
masked_image="masked_image.fits"
astarithmetic $image_filename -h0 $new_mask_filename -h1 x --output=$masked_image

#I create the radial flux profile
profile1_filename="profile_"$band"_flux.fits"
astscript-radial-profile $masked_image -h1 \
         --mode=img --center=$x_cen,$y_cen \
         --rmax=$max_radius \
         -p $pa -Q $ar \
         --undersample=$pix_per_aperture \
         --measure=sigclip-mean,sigclip-std,sigclip-number \
         --sigmaclip=5,0.1 \
         --output=$profile1_filename  
         #--instd=$sky_std \
          
#I convert from a flux table to a surface brightness table
profile2_filename="profile_"$band".fits"
asttable $profile1_filename -c1 -c'arith $1 '$pix_scale' x' \
         -c'arith $1 '$pix_scale' x '$phys_scale' x' \
         -c'arith $2' \
     -c'arith $2 log10 -2.5 x '$zp' + '$pix_scale' log10 5 x +' \
     -c'arith $4 sqrt set-den $3 den /' \
     -c'arith $4 sqrt set-den '$sky_std' den /' \
     -c'arith $4 sqrt set-den $3 den / set-sig_source_bin '$sky_std' den / set-sig_sky_bin sig_source_bin sig_source_bin x set-ssou2 sig_sky_bin sig_sky_bin x set-ssky2 ssou2 ssky2 + sqrt' \
     -c'arith $4 sqrt set-den $3 den / set-sig_source_bin '$sky_std' den / set-sig_sky_bin sig_source_bin sig_source_bin x set-ssou2 sig_sky_bin sig_sky_bin x set-ssky2 ssou2 ssky2 + sqrt $2 + $2 / log10 -2.5 x abs' \
         --colmetadata=1,distance_pix,pix,"radius in pix" \
         --colmetadata=2,distance_arcsec,arcsec,"radius in arcsec" \
         --colmetadata=3,distance_kpc,kpc,"radius in kpc" \
         --colmetadata=4,flux,count,"flux in counts" \
         --colmetadata=5,sb,mag/arcsec2,"surface brightness" \
         --colmetadata=6,sigma_source_bin,count,"sigma_source_bin" \
         --colmetadata=7,sigma_sky_bin,count,"sigma_sky_bin" \
         --colmetadata=8,delta_flux,count,"delta_flux_all_errors" \
         --colmetadata=9,sb_err,mag/arcsec2,"error in surface brightness" \
         --output=$profile2_filename
	     

